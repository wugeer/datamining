#!/bin/bash

# 清除日志

cat /dev/null > [Logname]

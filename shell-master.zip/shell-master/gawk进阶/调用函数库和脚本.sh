#!/bin/bash

#使用函数库和gawk脚本

gawk -f gawk函数库 -f gawk脚本 test

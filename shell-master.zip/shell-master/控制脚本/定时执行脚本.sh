#!/bin/bash

# testing the at command

at -f 4.sh 22:10

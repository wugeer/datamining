#!/bin/bash
#This script displays the date and who's logged on

#如果想在同一行显示
#echo -n -e 'The time is:\n\n'
echo The time is:
date
echo The one who has been logged is:
who




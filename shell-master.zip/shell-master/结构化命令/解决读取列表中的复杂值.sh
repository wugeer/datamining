#!/bin/bash

for test in I don\'t know if "this'll" work
do 
	echo "word:$test"
done
